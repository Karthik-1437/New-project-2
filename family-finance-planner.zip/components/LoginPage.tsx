
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: () => void;
}

const FamilyIllustration: React.FC = () => (
    <svg viewBox="0 0 400 300" className="w-full h-auto max-w-md mx-auto drop-shadow-lg">
        <defs>
            <clipPath id="circle-clip">
                <circle cx="200" cy="150" r="140" />
            </clipPath>
        </defs>
        
        {/* Background color */}
        <rect width="400" height="300" fill="#D1C4E9"/>

        {/* Yellow highlights */}
        <path d="M50 280 Q 80 260, 110 280" stroke="#FFD54F" fill="none" strokeWidth="4" strokeLinecap="round"/>
        <path d="M70 290 Q 100 270, 130 290" stroke="#FFD54F" fill="none" strokeWidth="4" strokeLinecap="round" opacity="0.6"/>

        {/* Family figures */}
        <g fillRule="evenodd">
            {/* Father */}
            <g transform="translate(180, 80)">
                <path d="M25,0 C38.8,0 50,11.2 50,25 C50,38.8 38.8,50 25,50 C11.2,50 0,38.8 0,25 C0,11.2 11.2,0 25,0 Z" fill="#6D4C41" transform="translate(5,0)"/>
                <path d="M10,40 L10,100 L65,100 L65,40 L50,40 Q45,30 37.5,30 Q30,30 25,40 Z" fill="#FFF8E1"/>
                <rect x="15" y="100" width="45" height="90" fill="#424242"/>
                <path d="M20,60 H55" stroke="#212121" strokeWidth="3"/>
                <path d="M20,75 H50" stroke="#212121" strokeWidth="3"/>
            </g>
            {/* Mother */}
            <g transform="translate(230, 95)">
                <path d="M25,0 C38.8,0 50,11.2 50,25 C50,38.8 38.8,50 25,50 C11.2,50 0,38.8 0,25 C0,11.2 11.2,0 25,0 Z" fill="#A1887F" transform="translate(10,0)"/>
                <path d="M-5,35 Q35, -10 75, 35 L70,50 Q35, 15 0, 50Z" fill="#212121"/>
                <path d="M15,45 L15,100 L60,100 L60,45 A25 25 0 0 0 15 45 Z" fill="#FFD54F"/>
                <path d="M15 95 L 60 95 L 50 175 L 25 175 Z" fill="#212121"/>
            </g>
             {/* Child 1 (daughter) */}
            <g transform="translate(150, 160)">
                <path d="M15,0 C23.2,0 30,6.8 30,15 C30,23.2 23.2,30 15,30 C6.8,30 0,23.2 0,15 C0,6.8 6.8,0 15,0 Z" fill="#A1887F" transform="translate(5,0)"/>
                <path d="M-5,20 Q20, -5 45, 20 L40,30 Q20, 10 -2, 30Z" fill="#212121"/>
                <path d="M5,28 L35,28 L30,90 L10,90 Z" fill="#FFD54F"/>
            </g>
            {/* Child 2 (baby) */}
            <g transform="translate(290, 80)">
                 <path d="M15,0 C23.2,0 30,6.8 30,15 C30,23.2 23.2,30 15,30 C6.8,30 0,23.2 0,15 C0,6.8 6.8,0 15,0 Z" fill="#6D4C41" transform="translate(5,0)"/>
                <path d="M10,25 L10,60 L35,60 L35,25 Z" fill="#FFF8E1"/>
                <path d="M35,10 L45,5" stroke="#FFD54F" strokeWidth="3" strokeLinecap="round"/>
                <path d="M38,15 L48,10" stroke="#FFD54F" strokeWidth="3" strokeLinecap="round"/>
            </g>
        </g>
    </svg>
);


const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
            onLogin();
            setIsLoading(false);
        }, 1000);
    };

    return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-brand-purple/30">
            <div className="w-full max-w-5xl mx-auto grid md:grid-cols-2 gap-8 items-center">
                <div className="text-center md:text-left">
                    <h1 className="text-4xl md:text-5xl font-bold text-brand-dark-purple leading-tight">
                        Financial Management for Families
                    </h1>
                    <p className="mt-4 text-lg text-slate-600">
                        Take control of your household finances with smart budgeting, expense tracking, and savings goals.
                    </p>
                    <div className="hidden md:block mt-8">
                         <FamilyIllustration />
                    </div>
                </div>
                <div className="bg-white/70 backdrop-blur-sm p-8 rounded-2xl shadow-2xl">
                    <h2 className="text-2xl font-bold text-center text-brand-dark-purple mb-6">Welcome Back!</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-slate-700">
                                Email Address
                            </label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="mt-1 block w-full px-4 py-3 bg-white border border-slate-300 rounded-lg shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-dark-purple focus:border-brand-dark-purple transition"
                                placeholder="you@example.com"
                            />
                        </div>
                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                                Password
                            </label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                autoComplete="current-password"
                                required
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="mt-1 block w-full px-4 py-3 bg-white border border-slate-300 rounded-lg shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-dark-purple focus:border-brand-dark-purple transition"
                                placeholder="••••••••"
                            />
                        </div>
                        <div>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-base font-semibold text-white bg-brand-dark-purple hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-dark-purple transition-transform transform hover:scale-105 disabled:bg-slate-400 disabled:cursor-not-allowed"
                            >
                                {isLoading ? 'Logging In...' : 'Log In'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
