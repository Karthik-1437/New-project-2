
import React, { useState, useMemo, useCallback } from 'react';
import { Transaction, TransactionType, ExpenseCategory, Budget } from '../types';
import { getFinancialAdvice } from '../services/geminiService';
import { HomeIcon, ShoppingCartIcon, PiggyBankIcon, LogoutIcon, SparklesIcon } from './icons';

interface DashboardProps {
    onLogout: () => void;
}

const initialTransactions: Transaction[] = [
    { id: '1', date: '2024-07-15', description: 'Monthly Salary', amount: 5000, type: TransactionType.INCOME, category: ExpenseCategory.NEEDS },
    { id: '2', date: '2024-07-15', description: 'Rent', amount: 1800, type: TransactionType.EXPENSE, category: ExpenseCategory.NEEDS },
    { id: '3', date: '2024-07-16', description: 'Groceries', amount: 450, type: TransactionType.EXPENSE, category: ExpenseCategory.NEEDS },
    { id: '4', date: '2024-07-18', description: 'Dinner Out', amount: 120, type: TransactionType.EXPENSE, category: ExpenseCategory.WANTS },
    { id: '5', date: '2024-07-20', description: 'Utilities', amount: 150, type: TransactionType.EXPENSE, category: ExpenseCategory.NEEDS },
    { id: '6', date: '2024-07-22', description: 'Movie Tickets', amount: 40, type: TransactionType.EXPENSE, category: ExpenseCategory.WANTS },
    { id: '7', date: '2024-07-25', description: 'Savings Transfer', amount: 1000, type: TransactionType.EXPENSE, category: ExpenseCategory.SAVINGS },
];

const CategoryIcon: React.FC<{ category: ExpenseCategory }> = ({ category }) => {
    const iconClasses = "w-8 h-8 p-1.5 rounded-full text-white";
    switch (category) {
        case ExpenseCategory.NEEDS:
            return <HomeIcon className={`${iconClasses} bg-blue-500`} />;
        case ExpenseCategory.WANTS:
            return <ShoppingCartIcon className={`${iconClasses} bg-purple-500`} />;
        case ExpenseCategory.SAVINGS:
            return <PiggyBankIcon className={`${iconClasses} bg-green-500`} />;
        default:
            return null;
    }
};

const ProgressBar: React.FC<{ value: number; max: number; color: string }> = ({ value, max, color }) => {
    const percentage = max > 0 ? (value / max) * 100 : 0;
    return (
        <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className={`${color} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
        </div>
    );
};

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
    const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
    const [aiAdvice, setAiAdvice] = useState<string>('');
    const [isFetchingAdvice, setIsFetchingAdvice] = useState(false);

    const monthlyIncome = 5000;
    const emergencyFundGoal = 15000;

    const budget: Budget = useMemo(() => ({
        needs: monthlyIncome * 0.5,
        wants: monthlyIncome * 0.3,
        savings: monthlyIncome * 0.2,
    }), [monthlyIncome]);
    
    const { totalExpenses, expensesByCategory, totalSavings } = useMemo(() => {
        const expensesByCategory = {
            [ExpenseCategory.NEEDS]: 0,
            [ExpenseCategory.WANTS]: 0,
            [ExpenseCategory.SAVINGS]: 0,
        };
        let totalExpenses = 0;

        transactions.forEach(t => {
            if (t.type === TransactionType.EXPENSE) {
                expensesByCategory[t.category] += t.amount;
                totalExpenses += t.amount;
            }
        });
        
        return { totalExpenses, expensesByCategory, totalSavings: expensesByCategory[ExpenseCategory.SAVINGS]};
    }, [transactions]);
    
    const remainingBalance = monthlyIncome - totalExpenses;

    const handleGetAdvice = useCallback(async () => {
        setIsFetchingAdvice(true);
        setAiAdvice('');
        try {
            const advice = await getFinancialAdvice(monthlyIncome, transactions, budget, emergencyFundGoal);
            setAiAdvice(advice);
        } catch (error) {
            console.error(error);
            setAiAdvice("Failed to fetch advice. Please try again.");
        } finally {
            setIsFetchingAdvice(false);
        }
    }, [monthlyIncome, transactions, budget, emergencyFundGoal]);

    return (
        <div className="min-h-screen bg-slate-50 text-slate-800">
            <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-10 shadow-md">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-brand-dark-purple">Family Dashboard</h1>
                    <button onClick={onLogout} className="flex items-center gap-2 text-slate-600 hover:text-brand-dark-purple transition-colors font-semibold">
                        <LogoutIcon className="w-6 h-6" />
                        <span>Logout</span>
                    </button>
                </div>
            </header>

            <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left Column: Budget & Savings */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-white p-6 rounded-2xl shadow-lg">
                            <h2 className="text-xl font-bold mb-4">Budget Overview (50/30/20)</h2>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between items-baseline mb-1">
                                        <span className="font-semibold text-blue-600">Needs</span>
                                        <span className="text-sm">${expensesByCategory.Needs.toFixed(2)} / ${budget.needs.toFixed(2)}</span>
                                    </div>
                                    <ProgressBar value={expensesByCategory.Needs} max={budget.needs} color="bg-blue-500" />
                                </div>
                                <div>
                                    <div className="flex justify-between items-baseline mb-1">
                                        <span className="font-semibold text-purple-600">Wants</span>
                                        <span className="text-sm">${expensesByCategory.Wants.toFixed(2)} / ${budget.wants.toFixed(2)}</span>
                                    </div>
                                    <ProgressBar value={expensesByCategory.Wants} max={budget.wants} color="bg-purple-500" />
                                </div>
                                <div>
                                    <div className="flex justify-between items-baseline mb-1">
                                        <span className="font-semibold text-green-600">Savings</span>
                                        <span className="text-sm">${expensesByCategory.Savings.toFixed(2)} / ${budget.savings.toFixed(2)}</span>
                                    </div>
                                    <ProgressBar value={expensesByCategory.Savings} max={budget.savings} color="bg-green-500" />
                                </div>
                            </div>
                        </div>

                         <div className="bg-white p-6 rounded-2xl shadow-lg">
                            <h2 className="text-xl font-bold mb-4">Emergency Fund</h2>
                            <p className="text-center text-3xl font-bold text-green-600">${totalSavings.toLocaleString()}</p>
                            <p className="text-center text-slate-500 mb-4">of ${emergencyFundGoal.toLocaleString()} goal</p>
                             <ProgressBar value={totalSavings} max={emergencyFundGoal} color="bg-green-500" />
                        </div>

                        <div className="bg-gradient-to-br from-brand-dark-purple to-purple-700 p-6 rounded-2xl shadow-lg text-white">
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><SparklesIcon className="w-6 h-6" />AI Financial Advisor</h2>
                            {aiAdvice ? (
                                <ul className="list-disc list-inside space-y-2 text-purple-100">
                                    {aiAdvice.split('\n').filter(line => line.trim().startsWith('*') || line.trim().startsWith('-')).map((line, index) => (
                                        <li key={index}>{line.replace(/[-*]\s*/, '')}</li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-purple-200">Get personalized tips to improve your family's financial health.</p>
                            )}
                             <button onClick={handleGetAdvice} disabled={isFetchingAdvice} className="mt-4 w-full bg-brand-yellow text-brand-dark-purple font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-transform transform hover:scale-105 disabled:bg-slate-400 disabled:cursor-not-allowed">
                                {isFetchingAdvice ? 'Analyzing...' : 'Get Advice'}
                            </button>
                        </div>
                    </div>

                    {/* Right Column: Transactions */}
                    <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-lg">
                        <h2 className="text-xl font-bold mb-4">Recent Transactions</h2>
                        <ul className="divide-y divide-slate-100">
                            {transactions.filter(t => t.type === TransactionType.EXPENSE).map(t => (
                                <li key={t.id} className="py-4 flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                        <CategoryIcon category={t.category} />
                                        <div>
                                            <p className="font-semibold">{t.description}</p>
                                            <p className="text-sm text-slate-500">{t.date}</p>
                                        </div>
                                    </div>
                                    <p className={`font-bold ${t.type === TransactionType.INCOME ? 'text-green-600' : 'text-red-600'}`}>
                                        {t.type === TransactionType.EXPENSE ? '-' : '+'}${t.amount.toFixed(2)}
                                    </p>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Dashboard;
