
import { GoogleGenAI } from "@google/genai";
import { Transaction, ExpenseCategory, Budget } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getFinancialAdvice = async (
  income: number,
  transactions: Transaction[],
  budget: Budget,
  savingsGoal: number
): Promise<string> => {
  try {
    const expensesByCategory = transactions.reduce((acc, t) => {
        if (t.type === 'expense') {
            acc[t.category] = (acc[t.category] || 0) + t.amount;
        }
        return acc;
    }, {} as Record<ExpenseCategory, number>);

    const prompt = `
      You are an expert financial advisor for families. Analyze the following household financial data and provide 3-5 actionable, concise, and encouraging suggestions for improvement. 
      The family follows the 50/30/20 budgeting rule (50% needs, 30% wants, 20% savings).

      Financial Data:
      - Monthly Income: $${income.toFixed(2)}
      - Budget Allocation: 
        - Needs (50%): $${budget.needs.toFixed(2)}
        - Wants (30%): $${budget.wants.toFixed(2)}
        - Savings (20%): $${budget.savings.toFixed(2)}
      - Actual Spending This Month:
        - Needs: $${(expensesByCategory[ExpenseCategory.NEEDS] || 0).toFixed(2)}
        - Wants: $${(expensesByCategory[ExpenseCategory.WANTS] || 0).toFixed(2)}
      - Savings Contribution This Month: $${(expensesByCategory[ExpenseCategory.SAVINGS] || 0).toFixed(2)}
      - Emergency Fund Goal: $${savingsGoal.toFixed(2)}

      Based on this data, provide personalized advice. Focus on areas of overspending, opportunities for more savings, and positive reinforcement for good habits. Format the response as a bulleted list of suggestions. Do not include a preamble or conclusion. Just the list.
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error getting financial advice:", error);
    return "I'm sorry, I'm having trouble providing advice right now. Please check your connection and API key, and try again later.";
  }
};
