
export enum TransactionType {
  INCOME = 'income',
  EXPENSE = 'expense',
}

export enum ExpenseCategory {
  NEEDS = 'Needs',
  WANTS = 'Wants',
  SAVINGS = 'Savings',
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: TransactionType;
  category: ExpenseCategory;
}

export interface Budget {
  needs: number;
  wants: number;
  savings: number;
}
